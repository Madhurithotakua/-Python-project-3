import openpyxl

def get_input_data():
    roll_number = input("Enter Roll Number: ")
    name = input("Enter Name: ")
    return roll_number, name

def save_data_to_excel(roll_number, name):
    excel_file = "data.xlsx"

    try:
        # Load the existing workbook if it exists, or create a new one
        workbook = openpyxl.load_workbook(excel_file)
    except FileNotFoundError:
        workbook = openpyxl.Workbook()

    # Select the active sheet (the first sheet in the workbook)
    sheet = workbook.active

    # Append the new data to the next available row
    next_row = sheet.max_row + 1
    sheet.cell(row=next_row, column=1, value=roll_number)
    sheet.cell(row=next_row, column=2, value=name)

    # Save the data to the Excel file
    workbook.save(excel_file)

def main():
    print("Enter student details:")
    roll_number, name = get_input_data()

    # Save the data to the Excel sheet
    save_data_to_excel(roll_number, name)

    print("Data successfully stored in Excel!")

if __name__ == "__main__":
    main()
